from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from agents.base import Agent, RandomAgent
from agents.heuristic import HeuristicAgent
from agents.ppo.policy import PolicyAgent
from truco import actions as A
from truco.engine import TrucoHand
from truco.features import FEATURE_NAMES

from .dictionary import FEATURE_LABELS, base_rates


@dataclass
class Thought:
    kind: str
    action: int
    probs: dict[int, float] | None = None
    value: float | None = None
    raw_value: float | None = None
    beliefs: list[float] | None = None


def decide(agent: Agent, hand: TrucoHand, seat: int, value_scale: float = 4.0) -> Thought:
    legal = hand.legal_actions()
    if isinstance(agent, PolicyAgent):
        if agent.is_mute(hand):
            action = agent.act(hand, seat)
            return Thought("mute", action, {action: 1.0})
        probs, value, beliefs = agent.evaluate(hand, seat)
        action = agent.sample(probs)
        return Thought("policy", action, _over(legal, probs), value * value_scale, value, _partner(hand, beliefs))
    if isinstance(agent, RandomAgent):
        action = agent.act(hand, seat)
        return Thought("random", action, {a: 1.0 / len(legal) for a in legal})
    strategy = _strategy(agent, hand, seat)
    if strategy is not None:
        return Thought("policy", agent.act(hand, seat), strategy)
    return Thought("rules", agent.act(hand, seat))


def advise(agent: Agent, hand: TrucoHand, seat: int, value_scale: float = 4.0) -> Thought:
    legal = hand.legal_actions()
    if isinstance(agent, PolicyAgent):
        if agent.is_mute(hand):
            action = agent.act(hand, seat)
            return Thought("mute", action, {action: 1.0})
        probs, value, beliefs = agent.evaluate(hand, seat)
        options = _over(legal, probs)
        best = max(options, key=options.get)
        return Thought("policy", best, options, value * value_scale, value, _partner(hand, beliefs))
    strategy = _strategy(agent, hand, seat)
    if strategy is not None:
        return Thought("policy", max(strategy, key=strategy.get), strategy)
    signals = getattr(agent, "use_signals", True)
    return Thought("rules", HeuristicAgent(seed=len(hand.history), use_signals=signals).act(hand, seat))


def _partner(hand: TrucoHand, beliefs) -> list[float] | None:
    return beliefs.tolist() if hand.rules.num_players == 4 else None


def _strategy(agent: Agent, hand: TrucoHand, seat: int) -> dict[int, float] | None:
    lookup = getattr(agent, "strategy", None)
    probs = None if lookup is None else lookup(hand, seat)
    if probs is None:
        return None
    total = float(probs.sum()) or 1.0
    return {a: float(p) / total for a, p in zip(hand.legal_actions(), probs)}


def _over(legal: list[int], probs: np.ndarray) -> dict[int, float]:
    total = float(sum(probs[a] for a in legal)) or 1.0
    return {a: float(probs[a]) / total for a in legal}


def beliefs_payload(beliefs: list[float] | None) -> list[dict] | None:
    if beliefs is None:
        return None
    base = base_rates()[0]
    return [
        {"name": name, "label": FEATURE_LABELS[name], "p": round(float(p), 4), "base": round(float(base[i]), 4)}
        for i, (name, p) in enumerate(zip(FEATURE_NAMES, beliefs))
    ]


def context(hand: TrucoHand, you: bool = False) -> str:
    if hand.signal_phase:
        return "Elegís la seña para tu compañero" if you else "Elige la seña para su compañero"
    pending = hand.pending
    verb = "Respondés" if you else "Responde"
    if pending is not None:
        if pending.kind == "truco":
            return f"{verb} al {A.TRUCO_NAMES[pending.level - 1]}"
        return f"{verb} al envido"
    rounds = ("la primera", "la segunda", "la tercera")[min(hand.round, 2)]
    return f"{'Jugás' if you else 'Juega'} {rounds}"
